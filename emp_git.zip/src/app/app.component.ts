import { Component,OnInit  } from '@angular/core';
//import {CrudService} from './app.service';
import { Car } from './car';
import { CarService } from './car.service';
import {MatPaginatorModule} from '@angular/material/paginator';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
   providers:[CarService]
})
export class AppComponent implements OnInit{

VulFormValid:boolean=false;
  title = 'emp';
   cars: Car[];
  car = new Car('','','');
  config: any;
   p: Number = 1;
  count: Number = 2;
   constructor(private carService :CarService,private toastr: ToastrService){
   
      //Create dummy data
    
   
 }

 pageChanged(event){
    this.config.currentPage = event;
  }
  ngOnInit() {
    this.getCars();
  }
        

     testform:any= new FormGroup({
     name: new FormControl('', [Validators.required]),
    dis: new FormControl('', [Validators.required]),
    com: new FormControl('', [Validators.required]),
          });


    getCars(): void {
  this.carService.getAll().subscribe(
    (res: Car[]) => {
      this.cars = res;
    },
    (err) =>   this.toastr.error(err, 'Major Error')
  );
}


addCar(f) {

  if (this.testform.invalid) {
    this.VulFormValid = true;
    }
    else{
      this.VulFormValid = false;
     
 
    this.carService.store(this.car)
      .subscribe(
        (res: Car[]) => {
          // Update the list of cars
          this.cars = res;

          // Inform the user
         // this.success = 'Created successfully';
           this.toastr.success('Created successfully', 'SUCCESS!');
          // Reset the form
          f.reset();
        },
        (err) => this.toastr.error(err, 'Major Error') 
      );
    }
    
}

updateCar(name, com,dis,id) {
   
    let _item={
      name: name,
      com: com,
      dis: dis,
      id:+id
    };
    this.carService.update(_item)
      .subscribe(
        (res) => {
          this.cars    = res;
          this.toastr.success('Updated successfully', 'SUCCESS!');
          this.getCars();
        },
        (err) => this.toastr.error(err, 'Error') 
      );
}
  
  deleteCar(id) {
   
    
    this.carService.delete(+id)
      .subscribe(
        (res: Car[]) => {
          this.cars = res;
          this.toastr.success('Deleted successfully', 'SUCCESS!');
          this.getCars();
        },
        (err) => this.toastr.error(err, 'Error') 
      );
}


}
