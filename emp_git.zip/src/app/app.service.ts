import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class CrudService {
  //base api url
  public url = 'http://localhost/api/';
  constructor(private http: HttpClient) { }

  getProducts(){
  return this.http.get(this.url + 'select.php');
}
}