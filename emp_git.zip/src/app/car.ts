export class Car {
	 
    name: string;
    dis:string;
    com:   string;
    id?: number;
	constructor(
    name: string,
    dis:string,
    com:   string,id?: number){
		this.id=id;
		this.name=name;
		this.dis=dis;
		this.com=com;

    }
 
}