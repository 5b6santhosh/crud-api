export class Test {
 name: string
    selling_points: SellingPoint[]
}
export class SellingPoint {
    selling_point: string
}
